package ramirez.erik1p321;

public class Molusco extends EspecieMarina implements Movible, Alimentable{
    
    private String tipoDeConcha;

    public Molusco(String tipoDeConcha, String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        super(nombreComun, tanqueDeUbicacion, tipoDeAgua);
        this.tipoDeConcha = tipoDeConcha;
    }

    @Override
    public void alimentar() {
        System.out.println("Soy un molusco y me estoy alimentando...");
    }

    @Override
    public void respirar() {
        System.out.println("Molusco respirando a travez de branqueas");
    }

    @Override
    public void reproducirse() {
        System.out.println("Iniciando proceso de repoduccion sexual");
    }

    @Override
    public void realizarFuncionesBiologicas() {
        respirar();
        reproducirse();
    }
    
    @Override
    public void mover() {
        System.out.println(getNombreComun()+" esta explorando el lugar donde se lo movio.");
    }

    @Override
    public String toString() {
        return super.toString() + " | Tipo de concha : " + tipoDeConcha;
    }
}

