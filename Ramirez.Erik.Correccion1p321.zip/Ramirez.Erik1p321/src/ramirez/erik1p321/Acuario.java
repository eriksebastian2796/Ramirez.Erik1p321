package ramirez.erik1p321;

import java.util.ArrayList;
import java.util.List;
import ramirez.erik1p321.exceptions.EspecieMarinaDuplicatedException;

public class Acuario {

    List<EspecieMarina> especies;

    public Acuario() {
        especies = new ArrayList<>();
    }

    public void agregarEespecie(EspecieMarina e) {
        validarEspecie(e);
        especies.add(e);
    }

    private void validarEspecie(EspecieMarina e) {
        if (e == null) {
            throw new IllegalArgumentException("El tipo de especie no puede ser null");
        }
        if (especies.contains(e)) {
            throw new EspecieMarinaDuplicatedException();
        }
    }

    public void mostrarEspecie() {
        if (especies.isEmpty()) {
            System.out.println("Sin especies para mostrar");
        } else {
            for (EspecieMarina e : especies) {
                System.out.println(e.toString());
            }
        }
    }

    public void moverEspecies() {
        int contador = 0;
        for (EspecieMarina e : especies) {
            if (e instanceof Movible m) {
                m.mover();
                contador++;
            }else{
                System.out.println("Los Corales no pueden ser movidos.");
            }
        }
        System.out.println("Los peces y moluscos se movieron "
                + "correctamente.\nEspecies movidas: " + contador);
    }

    public List<EspecieMarina> filtrarPorTipoAgua(TipoDeAgua tipo) {
        List<EspecieMarina> filtradasPorTipo = new ArrayList<>();
        for (EspecieMarina e : especies) {
            if (e.getTipoDeAgua() == tipo) {
                filtradasPorTipo.add(e);
            }
        }
        return filtradasPorTipo;
    }
    
    public StringBuilder mostrarEspeciesPorTipo(TipoDeAgua tipo) {
        List<EspecieMarina> filtradas = filtrarPorTipoAgua(tipo);
        StringBuilder filtradasSB = new StringBuilder();
        if (filtradas.isEmpty()) {
            filtradasSB.append("No hay especies de tipo: ").append(tipo);
        } else {
            for (EspecieMarina e : filtrarPorTipoAgua(tipo)) {
                filtradasSB.append(e).append("\n");
            }
        }return filtradasSB;
    }
    
    public void realizarFuncionesBiologicas(){
        for (EspecieMarina e : especies) {
            e.realizarFuncionesBiologicas();
            if (e instanceof Alimentable a) {
                a.alimentar();
            }
        }
    }

}


