
package ramirez.erik1p321;

import java.util.Objects;

public abstract class EspecieMarina{
    
    private String nombreComun;
    private int tanqueDeUbicacion;
    private TipoDeAgua tipoDeAgua;

    public EspecieMarina(String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        this.nombreComun = nombreComun;
        this.tanqueDeUbicacion = tanqueDeUbicacion;
        this.tipoDeAgua = tipoDeAgua;
    }

    public String getNombreComun() {
        return nombreComun;
    }

    public TipoDeAgua getTipoDeAgua() {
        return tipoDeAgua;
    }
    
    public abstract void respirar();
    
    public abstract void reproducirse();
    
    public abstract void realizarFuncionesBiologicas();
    
    @Override
    public String toString() {
        return "Tipo de Agua :" + tipoDeAgua + "| Nombre de especie :" 
                + nombreComun + "| Tanque de ubicacion : T "+ tanqueDeUbicacion;
    }
    
        @Override
    public boolean equals(Object obj) {
        if (this == obj) 
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        EspecieMarina esp = (EspecieMarina) obj;
        return Objects.equals(nombreComun, esp.nombreComun) && tanqueDeUbicacion == (esp.tanqueDeUbicacion) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreComun, tanqueDeUbicacion);
    }
}

   







