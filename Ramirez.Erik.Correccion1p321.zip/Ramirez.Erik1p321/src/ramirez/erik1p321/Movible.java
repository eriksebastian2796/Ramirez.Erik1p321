
package ramirez.erik1p321;

public interface Movible {
    
    public void mover();
    }







