package ramirez.erik1p321;

public class Pez extends EspecieMarina implements Movible, Alimentable{
    
    private double longitudMaximaCm;

    public Pez(double longitudMaximaCm , String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        super(nombreComun, tanqueDeUbicacion, tipoDeAgua);
        this.longitudMaximaCm = longitudMaximaCm;
    }

    @Override
    public void alimentar() {
        System.out.println("Soy un pez y me estoy alimentando...");
    }

    @Override
    public void mover() {
        System.out.println(getNombreComun()+" esta nadando en su espacio nuevo.");
    }

    @Override
    public void respirar() {
        System.out.println("Pez respirando por branqueas");
    }

    @Override
    public void reproducirse() {
        System.out.println("Pez entrando en estapa de apareamento");
    }

    @Override
    public void realizarFuncionesBiologicas() {
        respirar();
        reproducirse();
    }

    @Override
    public String toString() {
        return super.toString() + " | Longitud Maxima: " + longitudMaximaCm + "cm.";
    }
}




