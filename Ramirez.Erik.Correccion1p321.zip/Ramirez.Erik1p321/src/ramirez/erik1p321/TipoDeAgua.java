
package ramirez.erik1p321;


public enum TipoDeAgua {
    
    AGUA_SALADA,
    AGUA_DULCE
    
}
