
package ramirez.erik1p321;

import java.util.ArrayList;
import java.util.List;
import ramirez.erik1p321.exceptions.EspecieMarinaDuplicatedException;

public class Acuario {
    
    List<EspecieMarina> especies;

    public Acuario() {
        especies = new ArrayList<>();
    }
    
    public void agregarEespecie(EspecieMarina e) {
        validarEspecie(e);
        especies.add(e);
    }

    private void validarEspecie(EspecieMarina e) {
        if (e == null) {
            throw new IllegalArgumentException("El tipo de especie no puede ser null");
        }
        for (EspecieMarina existente : especies) {
        if (existente.equals(e)) { 
            throw new EspecieMarinaDuplicatedException();
        }
        }
    }
    
  
    
    public void mostrarEspecie() {
        if (especies.isEmpty()) {
            System.out.println("Sin especies para mostrar");
        } else {
            for (EspecieMarina e : especies) {
                System.out.println(e.toString());
            }
        }
    }
    
    public void moverEspecies() {
        int contador = 0;
        for (EspecieMarina e : especies) {
            if (e instanceof Movible) {
                ((Movible) e).mover();
                contador++;
            } 
            System.out.println("Todas las especies moviles fueron movidas "
                    + "correctamente.\nEspecies movidas: "+contador);

        }
    }
    
    public void filtrarPorTipoAgua(TipoDeAgua tipo){
        StringBuilder filtradoPorTipo = null;
        for (EspecieMarina e : especies) {
            if (e.getTipoDeAgua().ordinal() == tipo.ordinal()) {
                filtradoPorTipo.append(e).append("\n");
            }
        filtradoPorTipo.toString();
        }
    }
    
    
    
    
    
    
}
