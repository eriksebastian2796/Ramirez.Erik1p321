
package ramirez.erik1p321.exceptions;


public class EspecieMarinaDuplicatedException extends RuntimeException{
    
    private final static String MESSAGE = "ERROR: EspecieMarinaDuplicatedException";
    
    public EspecieMarinaDuplicatedException() {

        this(MESSAGE);
    }
    
    public EspecieMarinaDuplicatedException(String message) {

        super(message);
    }
    
}
