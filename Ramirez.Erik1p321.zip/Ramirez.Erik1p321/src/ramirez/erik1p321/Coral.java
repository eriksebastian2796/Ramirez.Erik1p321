
package ramirez.erik1p321;

public class Coral extends EspecieMarina{
    
    private double profundidadIdeal;

    public Coral(double profundidadIdeal, String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        super(nombreComun, tanqueDeUbicacion, tipoDeAgua);
        this.profundidadIdeal = profundidadIdeal;
    }


    @Override
    public void respirar() {
        System.out.println("Comenzando difusión directa de oxígeno a través de la superficie de sus cuerpos");
    }

    @Override
    public void reproducirse() {
         System.out.println("Coral iniciando etapa de reproduccion");
    }

    @Override
    public void realizarFuncionesBiologicas() {
        respirar();
        reproducirse();
    }
    
    
    
    
}
