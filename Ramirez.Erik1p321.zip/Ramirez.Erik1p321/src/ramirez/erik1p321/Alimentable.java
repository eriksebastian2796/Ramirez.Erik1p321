
package ramirez.erik1p321;


public interface Alimentable {
    
    public abstract void alimentar();
    
}
