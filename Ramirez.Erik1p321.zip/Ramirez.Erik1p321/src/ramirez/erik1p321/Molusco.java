
package ramirez.erik1p321;


public class Molusco extends EspecieMarina implements Movible, Alimentable{
    
    private String tipoDeConcha;

    public Molusco(String tipoDeConcha, String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        super(nombreComun, tanqueDeUbicacion, tipoDeAgua);
        this.tipoDeConcha = tipoDeConcha;
    }

    @Override
    public void alimentar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void respirar() {
        System.out.println("Molusco espirando a travez de branqueas");
    }

    @Override
    public void reproducirse() {
        System.out.println("Iniciando proceso de repoduccion sexual");
    }

    @Override
    public void realizarFuncionesBiologicas() {
        respirar();
        reproducirse();
    }
    
    
    @Override
    public void mover() {
    }
    
    
    
}
