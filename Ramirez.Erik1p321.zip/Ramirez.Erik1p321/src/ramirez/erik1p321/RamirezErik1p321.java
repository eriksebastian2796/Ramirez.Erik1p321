
package ramirez.erik1p321;


public class RamirezErik1p321 {

    
    public static void main(String[] args) {
       
        Acuario acuario = new Acuario();
        
        EspecieMarina pez1 = new Pez(150, "Pez Payaso", 1, TipoDeAgua.AGUA_DULCE);
        EspecieMarina pez2 = new Pez(1200, "Pez Dorado", 1, TipoDeAgua.AGUA_DULCE);
        EspecieMarina coral1 = new Coral(150, "Coral Azul", 2, TipoDeAgua.AGUA_SALADA);
        EspecieMarina coral2 = new Coral (600, "Cora Dorado", 3, TipoDeAgua.AGUA_DULCE);
        EspecieMarina molusco1 = new Molusco("Espiralada", "Cangrejo", 4, TipoDeAgua.AGUA_SALADA);
        EspecieMarina molusco2 = new Molusco("Bivalva", "Langosta", 4, TipoDeAgua.AGUA_SALADA);
        EspecieMarina molusco3 = new Molusco("De playa", "Langostino", 4, TipoDeAgua.AGUA_SALADA);
        
        acuario.agregarEespecie(pez1);
        acuario.agregarEespecie(pez2);
        acuario.agregarEespecie(coral1);
        acuario.agregarEespecie(coral2);
        acuario.agregarEespecie(molusco1);
        acuario.agregarEespecie(molusco2);
        acuario.agregarEespecie(molusco3);
        
        acuario.moverEspecies();
        
        acuario.mostrarEspecie();
        
        
        
        
        
        
        
        
        
    }
    
}
