/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.erik1p321;

public class Pez extends EspecieMarina implements Movible, Alimentable{
    
    private double longitudMaximaCm;

    public Pez(double longitudMaximaCm , String nombreComun, int tanqueDeUbicacion, TipoDeAgua tipoDeAgua) {
        super(nombreComun, tanqueDeUbicacion, tipoDeAgua);
        this.longitudMaximaCm = longitudMaximaCm;
    }

    @Override
    public void alimentar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mover() {
    }

    @Override
    public void respirar() {
        System.out.println("Pez respirando por branqueas");
    }

    @Override
    public void reproducirse() {
        System.out.println("Pez entrando en estapa de apareamento");
    }

    @Override
    public void realizarFuncionesBiologicas() {
        respirar();
        reproducirse();
    }

    
    
    
    
}
